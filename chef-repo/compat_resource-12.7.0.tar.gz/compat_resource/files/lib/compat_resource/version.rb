module CompatResource
  VERSION = '12.7.0'
end
